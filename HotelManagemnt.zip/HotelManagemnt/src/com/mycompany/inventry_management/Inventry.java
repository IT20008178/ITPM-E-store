package com.mycompany.inventry_management;

public class Inventry {
	private int sid;
	private String name;
	private String a;
	private String b;
	private String c;
	private String z;
	private String x;
	private String contact;
	
	public Inventry(int sid, String name, String a, String b, String c, String z, String x,
			String contact) {
		
		this.sid = sid;
		this.name = name;
		this.a = a;
		this.b = b;
		this.c = c;
		this.z = z;
		this.x = x;
		this.contact = contact;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getA() {
		return a;
	}

	public void setA(String a) {
		this.a = a;
	}

	public String getB() {
		return b;
	}

	public void setB(String b) {
		this.b = b;
	}

	public String getC() {
		return c;
	}

	public void setC(String c) {
		this.c = c;
	}

	public String getZ() {
		return z;
	}

	public void setZ(String z) {
		this.z = z;
	}

	public String getX() {
		return x;
	}

	public void setX(String x) {
		this.x = x;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}
	
}
