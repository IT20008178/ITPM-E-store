package com.mycompany.inventry_management;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class addinventry
 */
@WebServlet("/addinventry")
public class addinventry extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		 	String itemid=request.getParameter("itemid");
	        String name=request.getParameter("name");
	        String a=request.getParameter("a");
	        String b=request.getParameter("b");
	        String c=request.getParameter("c");
	        String z=request.getParameter("z");
	        String x=request.getParameter("x");
	        String contactnu=request.getParameter("contact");
	        
	        boolean isTrue;
	        isTrue=inventrydbutil.addinventry(itemid, name, a, b, c, z, x, contactnu);
	        
	        if(isTrue==true){
	        RequestDispatcher dis = request.getRequestDispatcher("Sucessz.jsp");
	        dis.forward(request,response);
	        }
	        else{
	         RequestDispatcher dis2 = request.getRequestDispatcher("inventrysucess.jsp");
	        dis2.forward(request,response);
	        }
	       
	    }
	

	    

	}