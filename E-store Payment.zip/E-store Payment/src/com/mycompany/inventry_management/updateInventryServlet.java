package com.mycompany.inventry_management;

import java.io.IOException;

import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/updateInventryServlet")
public class updateInventryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String id=request.getParameter("itemid");
		String name=request.getParameter("name");
		String a=request.getParameter("a");
		String b=request.getParameter("b");
		String c=request.getParameter("c");
		String z=request.getParameter("z");
		String x=request.getParameter("x");
		String contact=request.getParameter("contact");
		
		boolean isTrue;
		
		isTrue=inventrydbutil.updateinventry(id, name, a, b, c, z, x, contact);
		
		if(isTrue==true) {
			
			List<Inventry> itemDetails=inventrydbutil.getInventryDetails(id);
			request.setAttribute("itemDetails",itemDetails);
			
			RequestDispatcher dis=request.getRequestDispatcher("inventryaccount.jsp");
			dis.forward(request,response);
		}
		else {
			List<Inventry> itemDetails=inventrydbutil.getInventryDetails(id);
			request.setAttribute("itemDetails",itemDetails);
			
			RequestDispatcher dis=request.getRequestDispatcher("inventryaccount.jsp");
			dis.forward(request,response);
		}
	}

}
