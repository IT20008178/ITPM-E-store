package com.mycompany.inventry_management;

import java.sql.Connection;



import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class inventrydbutil {
	
	private static boolean isSuccess;
	private static Connection con=null;
	private static Statement stmt=null;
	private static ResultSet rs=null;
	
		public static boolean validate(String inventryid) {

		
		
		try {
			 con = DBConnect.getConnection();
		     stmt =con.createStatement();
		     
		     String sql="select * from employee_details where Item_ID='"+inventryid+"'";
		     rs = stmt.executeQuery(sql);
		     
		     if(rs.next()) {
		    	 isSuccess=true;
		    	 
		     }
		     else {
		    	 isSuccess=false;
		     }
			
		}
		
		
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return isSuccess;
		
	}
	
		public static List<Inventry> getinventry(String inventryid){
			
			ArrayList<Inventry> inventry= new ArrayList<>();
			
			try {
				
				con = DBConnect.getConnection();
				stmt = con.createStatement();
				String sql="select * from employee_details where Item_ID='"+inventryid+"'";
				rs=stmt.executeQuery(sql);
				
				while(rs.next()) {
					 int id=rs.getInt(1);
			    	 String name=rs.getString(2);
			    	 String a=rs.getString(3);
			    	 String b=rs.getString(4);
			    	 String c=rs.getString(5);
			    	 String z=rs.getString(6);
			    	 String x=rs.getString(7);
			    	 String contact=rs.getString(8);
			    	 
			    	 Inventry item=new Inventry(id,name,a,b,c,z,x,contact);
			    	 inventry.add(item);
			    	 
			    	 
				}
			}
			catch(Exception e) {
				
				
				
			}
			
			
			return inventry;
		}
	
	public static boolean addinventry(String itemid,String name,String a,String b,String c,String z,String x,String contact){
		    
	        boolean isSuccess = false;
	        
	        try{
	        	
	        
	     con = DBConnect.getConnection();
	     stmt =con.createStatement();
	        
	        String sql="insert into employee_details values('"+itemid+"','"+name+"','"+a+"','"+b+"','"+c+"','"+z+"','"+x+"','"+contact+"')";
	        int rs = stmt.executeUpdate(sql);
	        
	        if(rs > 0){
	        isSuccess = true;
	        }
	        else{
	        isSuccess = false;
	        }
	        }
	        catch(Exception e){
	        e.printStackTrace();
	        }
	        
	        return isSuccess;
	    }
	    
	public static boolean updateinventry(String id,String name,String a,String b,String c,String z,String x,String contact) {
	
		try {
			con=DBConnect.getConnection();
			stmt=con.createStatement();
			String sql="update employee_details set Name='"+name+"',Exp_date='"+a+"',Catagory='"+b+"',Quntity='"+c+"',Unit_Price='"+z+"',Recive_date='"+x+"',Contact_Number='"+contact+"'"
					+"where Item_ID='"+id+"'";
			int rs=stmt.executeUpdate(sql);
			
			if(rs > 0) {
				isSuccess=true;
			}
			else {
				isSuccess=false;
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	return isSuccess;
	}
	public static List<Inventry> getInventryDetails(String Id){
		int convertedID=Integer.parseInt(Id);
		
		ArrayList<Inventry> item=new ArrayList<>();
		try {
			
			con = DBConnect.getConnection();
			stmt=con.createStatement();
			String sql = "select * from employee_details where Item_ID='"+convertedID+"'";
			rs=stmt.executeQuery(sql);
			
			while(rs.next()) {
				int Item_ID=rs.getInt(1);
				String Name=rs.getString(2);
				String Exp_date=rs.getString(3);
				String Catagory=rs.getString(4);
				String Quntity=rs.getString(5);
				String Unit_Price=rs.getString(6);
				String Recive_date=rs.getString(7);
				String Contact_Number=rs.getString(8);
				
				Inventry e = new Inventry(Item_ID,Name,Exp_date,Catagory,Quntity,Unit_Price,Recive_date,Contact_Number);
				item.add(e);
				
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return item;
	}
	
	public static boolean deleteInventry(String id) {
		
		int convId = Integer.parseInt(id);
		
		try {
			con=DBConnect.getConnection();
			stmt=con.createStatement();
			String sql="delete from employee_details where Item_ID='"+convId+"' ";
			int r=stmt.executeUpdate(sql);
			
			if(r>0){
				isSuccess=true;
			}
			else {
				isSuccess=false;
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return isSuccess;
	}
	
}

